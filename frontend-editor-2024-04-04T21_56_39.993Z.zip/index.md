#JS
// variaveis
  const mensagem = "Oi, tudo bem?";
// tipos de dados
  // number
  // string

// função 
  alert(mensagem);

  //objeto javascript
const participante = {
  nome: "Mayk Brito",
  email: "Mayk@gmail.com",
  dataInscrição: new Date(2024, 2, 22, 19, 20),
  dataCheckIn: new Date(2024, 2, 25, 22, 00)
}

//array
let participantes = [
  {
  nome: "Mayk Brito",
  email: "Mayk@gmail.com",
  dataInscrição: new Date(2024, 2, 22, 19, 20),
  dataCheckIn: new Date(2024, 2, 25, 22, 00)
  },
]

//estrutura de repetição - loop
  for(let participante of participantes){
    output = output + criarNovoParticipante(participante)
    //Faça algo aqui
    //Enquanto tiver pessoas nessa lista
  }

