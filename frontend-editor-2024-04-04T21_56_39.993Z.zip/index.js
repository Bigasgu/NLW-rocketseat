let participantes = [
  {
    nome: "Mayk Brito",
    email: "mayk@gmail.com",
    dataInscrição: new Date(2024, 2, 22, 19, 20),
    dataCheckIn: new Date(2024, 2, 25, 22, 0)
  },
  {
    nome: "Diego Fernandes",
    email: "diego@gmail.com",
    dataInscrição: new Date(2024, 2, 20, 19, 21),
    dataCheckIn: new Date(2024, 1, 23, 20, 0)
  },
  {
    nome: "Maria Oliveira",
    email: "maria.oliveira@gmail.com",
    dataInscrição: new Date(2024, 3, 1, 10, 30),
    dataCheckIn: new Date(2024, 3, 2, 15, 45)
  },
  {
    nome: "José Santos",
    email: "jose.santos@gmail.com",
    dataInscrição: new Date(2024, 3, 3, 14, 0),
    dataCheckIn: new Date(2024, 3, 4, 11, 30)
  },
  {
    nome: "Ana Paula",
    email: "ana.paula@hotmail.com",
    dataInscrição: new Date(2024, 3, 5, 9, 45),
    dataCheckIn: new Date(2024, 3, 6, 8, 20)
  },
  {
    nome: "Felipe Silva",
    email: "felipe.silva@gmail.com",
    dataInscrição: new Date(2024, 3, 7, 16, 10),
    dataCheckIn: new Date(2024, 3, 8, 13, 15)
  },
  {
    nome: "Camila Almeida",
    email: "camila.almeida@yahoo.com",
    dataInscrição: new Date(2024, 3, 9, 11, 20),
    dataCheckIn: new Date(2024, 3, 10, 10, 0)
  },
  {
    nome: "Roberto Lima",
    email: "roberto.lima@gmail.com",
    dataInscrição: new Date(2024, 3, 11, 20, 45),
    dataCheckIn: new Date(2024, 3, 12, 18, 30)
  },
  {
    nome: "Marta Pereira",
    email: "Marta@gmail.com",
    dataInscrição: new Date(2024, 3, 8, 11, 35),
    dataCheckIn: new Date(2024, 4, 1, 12, 31)
  },
  {
    nome: "Jorge Mattos",
    email: "Jorge.Mattos@gmail.com",
    dataInscrição: new Date(2024, 3, 9, 10, 28),
    dataCheckIn: new Date(2024, 3, 6, 26, 21)
  },
]

const criarNovoParticipante = (participante) => {
  const dataInscrição = dayjs(Date.now())
  .to(participante.dataInscrição)
  let dataCheckIn = dayjs(Date.now())
  .to(participante.dataCheckIn)

  //condicional
  if(participante.dataCheckIn == null){
    dataCheckIn = `
    <button
      data-email="${participante.email}"
      onclick="fazerCheckIn(event)"
    >
      Confirmar check-in
      
    </button>
    `
  }
 
  return `
    <tr>
      <td>
        <strong>
          ${participante.nome}
        </strong>
        <br>
        <small>
          ${participante.email}
        </small>
      </td>
      <td>${dataInscrição}</td>
      <td>${dataCheckIn}</td>
    </tr>
  `;

}

const atualizarLista = (participantes) => {
  let output = ""
  //estrutura de repetição - loop
  for(let participante of participantes){
    output = output + criarNovoParticipante(participante)
  }

  // substituir informação do HTML
  document
  .querySelector('tbody')
  .innerHTML = output

}

atualizarLista(participantes)

const adicionarParticipante = (event) => {
  event.preventDefault()

  const dadosDoFormulario = new FormData(event.target)

  const participante = {
    nome: dadosDoFormulario.get("nome"),
    email: dadosDoFormulario.get("email"),
    dataInscrição: new Date(),
    dataCheckIn: null
  }
  
  //verificar se participante ja existe
  const participanteExiste = participantes.find(
    (p) => 
      p.email == participante.email
    
  )
  
  if(participanteExiste){
    alert('Email ja cadastrado!')
    return
  }

  participantes = [participante, ...participantes]
  atualizarLista(participantes)

  //limpar formulario
  event.target.querySelector('[name="nome"]').value =""
  event.target.querySelector('[name="email"]').value = ""

}

const fazerCheckIn = (event) => {
  //confirmar se realmente quer o check-in
  const mensagemConfirmacao = "Tem certeza que deseja fazer o check-in?"
  if(confirm(mensagemConfirmacao)==false) {
    return
  }

  
  // encontrar o participante dentro da lista
  const participante = participantes.find(
    (p) => p.email == event.target.dataset.email 
  )
  // atualizar check-in do participante
  participante.dataCheckIn = new Date()
  // atualizar lista de participantes
  atualizarLista(participantes)
}